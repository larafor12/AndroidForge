# WhatsApp Business Internet Blocker

Android Studio project that attempts to block network access for WhatsApp Business (`com.whatsapp.w4b`) while allowing other apps to use the network.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on your Android phone.
5. Start the app and grant the VPN permission.
6. Tap "حجب WhatsApp Business".

## Important
Android's VPN routing behavior varies by version/device. This project uses VpnService and intentionally discards packets from the blocked app. It is not a guarantee that WhatsApp will always show exactly one check mark, because WhatsApp/Android can change connection behavior.
