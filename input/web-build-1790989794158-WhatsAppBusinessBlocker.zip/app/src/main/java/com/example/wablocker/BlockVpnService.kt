package com.example.wablocker

import android.content.pm.PackageManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import kotlin.concurrent.thread

class BlockVpnService : VpnService() {
    private var vpn: ParcelFileDescriptor? = null
    private var worker: Thread? = null

    companion object {
        @Volatile var running = false
        private const val WA_BUSINESS = "com.whatsapp.w4b"
    }

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        if (!running) startBlocking()
        return START_STICKY
    }

    private fun startBlocking() {
        try {
            val builder = Builder()
                .setSession("WhatsApp Business Blocker")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32)
                .addRoute("0.0.0.0", 0)

            // Put all traffic through this local VPN.
            // Allow every app EXCEPT WhatsApp Business to bypass the VPN.
            val pm = packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in apps) {
                if (app.packageName != packageName && app.packageName != WA_BUSINESS) {
                    try { builder.addDisallowedApplication(app.packageName) } catch (_: Exception) {}
                }
            }

            vpn = builder.establish()
            running = vpn != null

            if (running) {
                worker = thread(start = true, name = "vpn-blackhole") {
                    drainVpn()
                }
            }
        } catch (_: Exception) {
            running = false
            stopSelf()
        }
    }

    private fun drainVpn() {
        val fd = vpn ?: return
        FileInputStream(fd.fileDescriptor).use { input ->
            val buffer = ByteArray(32767)
            while (running) {
                try {
                    val n = input.read(buffer)
                    if (n < 0) break
                    // Deliberately discard packets: WhatsApp Business gets no network path.
                } catch (_: Exception) {
                    break
                }
            }
        }
    }

    override fun onDestroy() {
        running = false
        try { vpn?.close() } catch (_: Exception) {}
        vpn = null
        worker = null
        super.onDestroy()
    }

    override fun onRevoke() {
        stopSelf()
        super.onRevoke()
    }
}
