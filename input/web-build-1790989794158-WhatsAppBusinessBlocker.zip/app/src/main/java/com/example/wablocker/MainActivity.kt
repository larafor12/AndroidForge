package com.example.wablocker

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        button = findViewById(R.id.toggle)

        button.setOnClickListener {
            if (BlockVpnService.running) {
                stopService(Intent(this, BlockVpnService::class.java))
                updateUi(false)
            } else {
                val intent = VpnService.prepare(this)
                if (intent != null) {
                    startActivityForResult(intent, 100)
                } else {
                    startBlocker()
                }
            }
        }
        updateUi(BlockVpnService.running)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) startBlocker()
    }

    private fun startBlocker() {
        startService(Intent(this, BlockVpnService::class.java))
        updateUi(true)
    }

    private fun updateUi(on: Boolean) {
        status.text = if (on)
            "الحالة: حجب WhatsApp Business"
        else
            "الحالة: الإنترنت مفتوح"
        button.text = if (on) "إيقاف الحجب" else "حجب WhatsApp Business"
    }
}
